from app import db


class Person(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20))
    last_name = db.Column(db.String(20))
    age = db.Column(db.Integer)
    vehicles = db.relationship("Vehicle")


class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_name = db.Column(db.String(30), unique=True)
    seat_number = db.Column(db.Integer)
    wheels_number = db.Column(db.Integer)
    person_id = db.Column(db.Integer, db.ForeignKey('person.id'))
