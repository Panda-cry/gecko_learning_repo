from flask import request

from app import app, db
from models import Person, Vehicle
from schema import PersonSchema, VehicleSchema


@app.route('/')
def index():
    return "Hello"


@app.route('/person', methods=["POST"])
def car():
    if request.method == "POST":
        vehicle = Vehicle()

        vehicle.vehicle_name = request.json['vehicles']['vehicle_name']
        vehicle.seat_number = request.json['vehicles']['seat_number']
        vehicle.wheels_number = request.json['vehicles']['wheels_number']
        # vehicle.person_id = person.id

        person = Person()
        person.name = request.json['name']
        person.last_name = request.json['last_name']
        person.age = request.json['age']
        person.vehicles.append(vehicle)

        db.session.add(vehicle)
        db.session.add(person)

        db.session.commit()

        return 'PersonSchema().dump(request.json)'


@app.route('/get_persons')
def get_cars():
    persons = Person.query.all()

    return PersonSchema().dump(persons, many=True)


@app.route('/pagination/<int:page>')
def pagination(page):
    elements = Vehicle.query.paginate(page=page, per_page=2)
    return VehicleSchema().dump(elements, many=True)


@app.route('/add_vehicle/<int:id>', methods=['POST'])
def add_vehicle(id: int):
    person = Person.query.get(id)

    if person:
        vehicle = Vehicle()

        vehicle.vehicle_name = request.json['vehicle_name']
        vehicle.seat_number = request.json['seat_number']
        vehicle.wheels_number = request.json['wheels_number']
        vehicle.person_id = id

        db.session.add(vehicle)
        db.session.commit()

    return f"Vehicle with {vehicle.id} was added to database"


@app.route('/change_vehicle/<int:id>', methods=['PUT'])
def change_vehicle(id):
    vehicle = Vehicle.query.get(id)
    if vehicle:
        data_json = request.get_json()
        vehicle.seat_number = data_json['seat_number']
        vehicle.wheels_number = data_json['wheels_number']

        db.session.commit()

    return VehicleSchema().dump(vehicle)


@app.route('/delete_vehicle/<int:id>',methods=["DELETE"])
def delete_vehicle(id):
    vehicle = Vehicle.query.get(id)

    if vehicle:
        db.session.delete(vehicle)
        db.session.commit()
        return f"Deleted vehicle with id :{id}"