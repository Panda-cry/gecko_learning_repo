from marshmallow import Schema, fields


class CarShema(Schema):
    car_name = fields.Str()


class VehicleSchema(Schema):
    id = fields.Integer()
    vehicle_name = fields.Str()
    seat_number = fields.Integer()
    wheels_number = fields.Integer()
    person_id = fields.Integer()


class PersonSchema(Schema):
    id = fields.Integer()
    name = fields.Str()
    last_name = fields.Str()
    age = fields.Integer()
    vehicles = fields.List(fields.Nested(VehicleSchema))

